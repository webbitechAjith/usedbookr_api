const Config = {
    baseURL: 'https://usedbookr.com/demo/usedbookr/'
};

export default Config;