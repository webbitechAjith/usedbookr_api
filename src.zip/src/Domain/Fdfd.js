import React from 'react'
import Header from '../Common/pages/Header'

function Fdfd() {
  return (
    <div>
        <Header />
    </div>
  )
}

export default Fdfd