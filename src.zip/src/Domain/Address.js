import React from 'react'

import '../Common/assets/css/address.css'

function Address() {
    return (
        <div>
            
        </div>
    )
}

export default Address